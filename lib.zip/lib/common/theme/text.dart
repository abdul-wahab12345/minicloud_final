import 'package:flutter/material.dart';
import 'colors.dart';

TextStyle poppinsRegular()=>
    TextStyle(
        fontFamily: 'poppinsRegular',
        fontWeight: FontWeight.w500,
        color: kPositiveWhite,
        fontSize: 11);

TextStyle poppinsMedium()=>
    TextStyle(
        fontFamily: 'poppinsMedium',
        fontWeight: FontWeight.w500,
        color: kPositiveWhite,
        fontSize: 16);
        TextStyle poppinsStandard()=>
    TextStyle(
        fontFamily: 'poppinsMedium',
        fontWeight: FontWeight.w300,
        color: kPositiveWhite,
        fontSize: 14);